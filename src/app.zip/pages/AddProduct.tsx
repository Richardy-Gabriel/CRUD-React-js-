import ProductForm from '../components/ProductForm';
function AddProduct() {
    return (
        <div>
            <h1>Add Product</h1>
            <ProductForm />
        </div>
    );
}
export default AddProduct;